package com.ruview.mobile;

import android.app.*;import android.os.*;import android.graphics.Color;import android.net.wifi.WifiManager;import android.text.InputType;import android.view.*;import android.webkit.WebView;import android.webkit.WebSettings;import android.widget.*;import java.net.*;import java.util.*;import java.util.concurrent.*;

public class MainActivity extends Activity {
  WebView web; TextView status; EditText portEdit; Button startBtn; UdpReceiver receiver; Handler handler=new Handler(Looper.getMainLooper());
  @Override public void onCreate(Bundle b){super.onCreate(b); buildUi();}
  String localIp(){try{WifiManager wm=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE); int ip=wm.getConnectionInfo().getIpAddress(); return (ip&255)+"."+((ip>>8)&255)+"."+((ip>>16)&255)+"."+((ip>>24)&255);}catch(Exception e){return "unknown";}}
  void buildUi(){
    LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(5,10,15));
    LinearLayout bar=new LinearLayout(this); bar.setPadding(20,14,20,8); bar.setGravity(Gravity.CENTER_VERTICAL);
    TextView title=new TextView(this); title.setText("RuView Direct 3D"); title.setTextColor(Color.WHITE); title.setTextSize(20); bar.addView(title,new LinearLayout.LayoutParams(0,60,1));
    status=new TextView(this); status.setText("STOPPED"); status.setTextColor(Color.LTGRAY); bar.addView(status,new LinearLayout.LayoutParams(-2,60)); root.addView(bar);
    LinearLayout controls=new LinearLayout(this); controls.setPadding(20,0,20,8);
    TextView ip=new TextView(this); ip.setText("Phone IP: "+localIp()); ip.setTextColor(Color.WHITE); ip.setPadding(0,8,15,8); controls.addView(ip,new LinearLayout.LayoutParams(0,60,1));
    portEdit=new EditText(this); portEdit.setText("5005"); portEdit.setTextColor(Color.WHITE); portEdit.setHintTextColor(Color.GRAY); portEdit.setInputType(InputType.TYPE_CLASS_NUMBER); controls.addView(portEdit,new LinearLayout.LayoutParams(120,60));
    startBtn=new Button(this); startBtn.setText("START"); startBtn.setOnClickListener(v->toggle()); controls.addView(startBtn,new LinearLayout.LayoutParams(120,60)); root.addView(controls);
    web=new WebView(this); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); web.setBackgroundColor(Color.BLACK); web.loadUrl("file:///android_asset/index.html"); root.addView(web,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
  }
  void toggle(){ if(receiver!=null){receiver.shutdown();receiver=null;startBtn.setText("START");status.setText("STOPPED");return;} int p=5005;try{p=Integer.parseInt(portEdit.getText().toString());}catch(Exception ignored){} receiver=new UdpReceiver(p); receiver.start();startBtn.setText("STOP"); }
  void update(String text){handler.post(()->{status.setText(text); web.evaluateJavascript("window.onCsi("+org.json.JSONObject.quote(text)+")",null);});}
  @Override protected void onDestroy(){if(receiver!=null)receiver.shutdown();if(web!=null)web.destroy();super.onDestroy();}
  class UdpReceiver extends Thread { volatile boolean run=true; DatagramSocket sock; final int port; long frames=0,lastSeq=-1; double motion=0; double base=0;
    UdpReceiver(int p){port=p;}
    void stopReceiver(){run=false;if(sock!=null)sock.close();}
    void shutdown(){stopReceiver();}
    @Override public void run(){try{sock=new DatagramSocket(port);sock.setSoTimeout(1000);byte[] buf=new byte[4096];long lastUi=0;while(run){DatagramPacket dp=new DatagramPacket(buf,buf.length);try{sock.receive(dp);}catch(SocketTimeoutException e){continue;} byte[] d=Arrays.copyOfRange(dp.getData(),dp.getOffset(),dp.getOffset()+dp.getLength()); Frame f=parse(d);if(f==null)continue;frames++; double a=f.meanAmp; if(base==0)base=a; motion=0.92*motion+0.08*Math.min(1.0,Math.abs(a-base)/(Math.abs(base)+1)); base=0.995*base+0.005*a; if(System.currentTimeMillis()-lastUi>100){lastUi=System.currentTimeMillis();update("RUNNING  frames="+frames+"  seq="+f.seq+"  RSSI="+f.rssi+"  motion="+String.format(Locale.US,"%.2f",motion)); web.evaluateJavascript("window.onCsiData("+a+","+motion+","+f.rssi+","+f.sub+", "+f.ant+")",null);}}}catch(Exception e){update("ERROR: "+e.getClass().getSimpleName());}}
    Frame parse(byte[] d){if(d.length<20)return null;int magic=(d[0]&255)|((d[1]&255)<<8)|((d[2]&255)<<16)|((d[3]&255)<<24);if(magic!=0xC5110001)return null;int ant=d[5]&255;int sub=(d[6]&255)|((d[7]&255)<<8);long seq=((long)d[12]&255)|(((long)d[13]&255)<<8)|(((long)d[14]&255)<<16)|(((long)d[15]&255)<<24);int rssi=d[16];int count=ant*sub; if(ant<1||ant>4||sub<1||count>1024||d.length<20+count*2)return null;double sum=0;for(int i=0;i<count;i++){int I=d[20+i*2];int Q=d[21+i*2];sum+=Math.sqrt(I*I+Q*Q);}return new Frame(seq,rssi,sub,ant,sum/count);}
  }
  static class Frame{long seq;int rssi,sub,ant;double meanAmp;Frame(long s,int r,int su,int a,double m){seq=s;rssi=r;sub=su;ant=a;meanAmp=m;}}
}
