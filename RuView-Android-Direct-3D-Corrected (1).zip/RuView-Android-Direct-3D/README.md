# RuView Android Direct 3D

Direct Android UDP CSI receiver and lightweight 3D-style visualization for the RuView ESP32 CSI node.

## Build

GitHub Actions builds `app-debug.apk` automatically on push to `main`, or manually from **Actions → Build Android APK → Run workflow**.

## Network

ESP32 and Android phone must be on the same Wi-Fi network. The ESP32 sends ADR-018 CSI UDP frames to the phone's IP on port 5005 by default.
